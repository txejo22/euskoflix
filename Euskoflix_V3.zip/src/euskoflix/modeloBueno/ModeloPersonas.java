package euskoflix.modeloBueno;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

public class ModeloPersonas {

	private HashMap<Integer,ArrayList<String>> hashmap;
	private static ModeloPersonas miModeloPersonas;
	
	private ModeloPersonas() {
		hashmap=new HashMap<Integer,ArrayList<String>>();
	}
	
	public static ModeloPersonas getModeloPersonas() {
		if(miModeloPersonas==null) {
			miModeloPersonas=new ModeloPersonas();
		}
		return miModeloPersonas;
	}

}
