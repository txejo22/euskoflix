package euskoflix.modeloBueno;

import java.util.HashMap;
import java.util.Map;

import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

public class MovieTitles {
		
		//ATRIBUTOS
		private HashMap<Integer,String> hashMap;
		private static MovieTitles miHashMap;
		
		//CONSTRUCTORA
		private MovieTitles() {
			this.hashMap=new HashMap<Integer,String>();
		}
		
		public static MovieTitles getMovieTitles() {
			if(miHashMap==null) {
				miHashMap=new MovieTitles();
			}
			return miHashMap;
		}
		
		public void put(int pMovieId, String pTitle) {
			this.hashMap.put(pMovieId, pTitle);
		}
		
		public TableModel toTableModelTitle() {
			System.out.println("--> HASHMAP TO JTABLE MODEL");
		    DefaultTableModel model = new DefaultTableModel(
		        new Object[] { "MovieId", "Title" }, 0
		    );
		    for (Map.Entry<?, ?> entry : hashMap.entrySet()) {
		        model.addRow(new Object[] { entry.getKey(), entry.getValue() });
		    }
		    System.out.println("<-- HASHMAP TO JTABLE MODEL COMPLETADO");
		    return model;   
		}
	}
