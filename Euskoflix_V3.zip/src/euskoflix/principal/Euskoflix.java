package euskoflix.principal;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Map;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import euskoflix.modeloBueno.MatrizValoraciones;
import euskoflix.modeloBueno.ModeloProducto;
import euskoflix.modeloBueno.MovieTitles;
import euskoflix.vista.VentanaMostrarDatos;

public class Euskoflix {
	private static String workspace; //args
	
	private static String movie_ratings;
	private static String movie_tags;
	private static String movie_titles;
	
	private static Euskoflix miEuskoflix;
	
	public static void main(String[] args) throws IOException {	
		workspace=args[0];
		
		movie_ratings=workspace+"\\euskoflix\\src\\euskoflix\\archivos\\movie_ratings.csv";
		movie_tags=workspace+"\\euskoflix\\src\\euskoflix\\archivos\\movie_tags.csv";
		movie_titles=workspace+"\\euskoflix\\src\\euskoflix\\archivos\\movie_titles.csv";

		
		MatrizValoraciones.getValoracionesUsuario().cargar(movie_ratings);
		ModeloProducto.getModeloProducto().cargar(movie_tags);
		
		//Euskoflix.getEuskoflix().cargarDatos();
		VentanaMostrarDatos v=new VentanaMostrarDatos();
	}
	
	private Euskoflix() {
		
	}
	
	public static Euskoflix getEuskoflix() {
		if(miEuskoflix==null) {
			miEuskoflix=new Euskoflix();
		}
		return miEuskoflix;
	}
	
	public void cargarDatos() throws IOException {
		//cargarMovieRatings();
		//cargarMovieTags();
		cargarMovieTitles();
	}
	
	public void cargarMovieTitles() throws IOException {
		BufferedReader br=null;
		try {
			System.out.println("--> CARGANDO MOVIE TITLES...");
			br=new BufferedReader(new FileReader(movie_titles));
			String linea=br.readLine();
			while(linea!=null) {
				String[] datos=linea.split(";");
				int movieId=Integer.parseInt(datos[0]);
				String title=datos[1];
				MovieTitles.getMovieTitles().put(movieId, title);
				linea=br.readLine();
			}
			br.close();
			System.out.println("<-- MOVIE TITLES CARGADO");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	
		
	
		
	
}
